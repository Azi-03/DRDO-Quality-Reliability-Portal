from flask import Flask, jsonify, render_template, request, redirect, url_for, session, send_from_directory, flash, make_response
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from functools import wraps
import os
import json
from datetime import datetime

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY') or 'dev-key-change-in-production'

# Configuration
UPLOAD_FOLDER = 'uploads'
TEMPLATE_FOLDER = 'templates'
ALLOWED_EXTENSIONS = {'pdf'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['TEMPLATE_FOLDER'] = TEMPLATE_FOLDER

# Ensure folders exist
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(TEMPLATE_FOLDER, exist_ok=True)

# Database simulation
divisions = {
    1: {'id': 'QP/QPG', 'password': generate_password_hash('pass1')},
    2: {'id': 'QP/Material/Characterisation', 'password': generate_password_hash('pass2')},
    3: {'id': 'QP/Material/LPE', 'password': generate_password_hash('pass3')},
    4: {'id': 'QP/Material/Bulk/CZT', 'password': generate_password_hash('pass4')},
    5: {'id': 'QP/PMN-PT/Project:01', 'password': generate_password_hash('pass5')},
    6: {'id': 'QP/Material/Bulk/SiC', 'password': generate_password_hash('pass6')},
    7: {'id': 'QP/Material/Epitaxy/MOCVD', 'password': generate_password_hash('pass7')},
    8: {'id': 'QP/Material/Epitaxy/MBE', 'password': generate_password_hash('pass8')},
    9: {'id': 'QP/Device/MMIC-Fab', 'password': generate_password_hash('pass9')},
    10: {'id': 'QP/Device/Laser', 'password': generate_password_hash('pass10')},
    11: {'id': 'QP/Device/IR Fab', 'password': generate_password_hash('pass11')},
    12: {'id': 'QP/Device/lon-Implantation', 'password': generate_password_hash('pass12')},
    13: {'id': 'QP/Device/MEMS', 'password': generate_password_hash('pass13')},
    14: {'id': 'QP/Device/Instrumentation', 'password': generate_password_hash('pass14')},
    15: {'id': 'QP/Device/EnggServ/Cooler', 'password': generate_password_hash('pass15')},
    16: {'id': 'QP/Test& Intg/Assembly', 'password': generate_password_hash('pass16')},
    17: {'id': 'QP/Test& Intg/RF-Test', 'password': generate_password_hash('pass17')},
    18: {'id': 'QP/Test&Intg/IRS&AE', 'password': generate_password_hash('pass18')},
    19: {'id': 'QP/Device/TEC', 'password': generate_password_hash('pass19')},
    20: {'id': 'QP/Sensor Tech/Acoustic Sensor', 'password': generate_password_hash('pass20')},
    21: {'id': 'QP/Support Services/TS', 'password': generate_password_hash('pass21')},
    22: {'id': 'QP/Support Services/Safety and Fire Safety', 'password': generate_password_hash('pass22')},
    23: {'id': 'QP/TIRC', 'password': generate_password_hash('pass23')},
    24: {'id': 'QP/HR', 'password': generate_password_hash('pass24')},
    25: {'id': 'QP/Support Services/ITG', 'password': generate_password_hash('pass25')}
}

admin_credentials = {'username': 'admin', 'password': generate_password_hash('admin123')}
files_db = {i: [] for i in range(1, 26)}
template_files = {'A': None, 'B': None, 'C': None, 'D': None, 'E': None, 'F': None}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def is_authenticated():
    return 'division' in session or 'admin' in session

def is_admin():
    return 'admin' in session

def get_template_name(template_type):
    names = {
        'A': 'Quality Report',
        'B': 'Reliability Test',
        'C': 'Inspection Checklist',
        'D': 'Failure Analysis',
        'E': 'Audit Report',
        'F': 'Compliance Document'
    }
    return names.get(template_type, f'Template {template_type}')

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get('admin_logged_in'):
            return redirect(url_for('admin_login'))
        return f(*args, **kwargs)
    return decorated_function

# ROUTES
@app.route('/')
def home():
    return render_template('index.html')

@app.route('/login', methods=['POST'])
def login():
    division_id = request.form.get('division_id')
    password = request.form.get('password')
    
    try:
        div_num = int(division_id[3:]) if division_id.startswith('div') else int(division_id)
        if div_num in divisions and check_password_hash(divisions[div_num]['password'], password):
            session['division'] = f'div{div_num}'
            return jsonify({'success': True})
    except (ValueError, TypeError):
        pass
    
    return jsonify({'success': False, 'error': 'Invalid credentials'}), 401

@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        if (username == admin_credentials['username'] and 
            check_password_hash(admin_credentials['password'], password)):
            session['admin_logged_in'] = True
            session['admin_username'] = username
            return redirect(url_for('admin_dashboard'))
        else:
            flash('Invalid credentials', 'error')
            return redirect(url_for('admin_login'))
    
    return render_template('admin_login.html')

@app.route('/admin/logout')
def admin_logout():
    session.pop('admin_logged_in', None)
    session.pop('admin_username', None)
    return redirect(url_for('home'))

@app.route('/admin/dashboard')
@admin_required
def admin_dashboard():
    total_files = sum(len(files) for files in files_db.values())
    active_templates = sum(1 for template in template_files.values() if template is not None)
    
    divisions_data = []
    for division_id in range(1, 26):
        divisions_data.append({
            'id': division_id,
            'name': divisions[division_id]['id'],
            'file_count': len(files_db.get(division_id, [])),
            'credentials': divisions[division_id]
        })

    divisions_json = {str(k): v['id'] for k, v in divisions.items()}

    return render_template('new_admin_dashboard.html',
                         divisions=divisions_data,
                         total_files=total_files,
                         active_templates=active_templates,
                         template_files=template_files,
                         divisions_json=json.dumps(divisions_json),
                         get_template_name=get_template_name,
                         current_datetime=datetime.now())

@app.route('/division/<int:division_id>/files')
@admin_required
def view_division_files(division_id):
    if division_id not in divisions:
        flash('Division not found', 'error')
        return redirect(url_for('admin_dashboard'))
    
    division_data = {
        'id': division_id,
        'name': divisions[division_id]['id'],
        'files': files_db.get(division_id, [])
    }
    return render_template('division_files.html', division=division_data)

@app.route('/update_division_credentials', methods=['POST'])
def update_division_credentials():
    if not is_admin():
        return jsonify({'error': 'Unauthorized'}), 401
    
    data = request.get_json()
    try:
        division_id = int(data['division'])
        if division_id in divisions:
            divisions[division_id]['id'] = data['id']
            divisions[division_id]['password'] = generate_password_hash(data['password'])
            return jsonify({'success': True})
    except (ValueError, KeyError):
        pass
    
    return jsonify({'success': False, 'error': 'Invalid request'}), 400

@app.route('/division')
def division_portal():
    if 'division' not in session:
        return redirect(url_for('home'))
    
    division_id = int(session['division'][3:])
    division_data = {
        'id': division_id,
        'name': divisions[division_id]['id'],
        'files': files_db.get(division_id, [])
    }
    return render_template('division.html', division=division_data)

@app.route('/api/files', methods=['GET'])
def get_files():
    if 'division' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    division_id = int(session['division'][3:])
    files = files_db.get(division_id, [])
    return jsonify(files)

@app.route('/api/files', methods=['POST'])
def upload_file():
    if 'division' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'}), 400
    
    file = request.files['file']
    file_type = request.form.get('file_type')
    
    if not file or file.filename == '':
        return jsonify({'error': 'No selected file'}), 400
    
    if not allowed_file(file.filename):
        return jsonify({'error': 'Invalid file type'}), 400
    
    division_id = int(session['division'][3:])
    filename = secure_filename(file.filename)
    save_path = os.path.join(app.config['UPLOAD_FOLDER'], f"div{division_id}_{file_type}_{filename}")
    
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    file.save(save_path)
    
    file_id = str(len(files_db.get(division_id, [])) + 1)
    new_file = {
        'id': file_id,
        'name': filename,
        'type': file_type,
        'uploadDate': datetime.now().strftime('%Y-%m-%d'),
        'size': f"{os.path.getsize(save_path)/1024/1024:.1f} MB",
        'archived': False
    }
    
    if division_id not in files_db:
        files_db[division_id] = []
    files_db[division_id].append(new_file)
    
    return jsonify({'success': True, 'message': 'File uploaded successfully'})

@app.route('/api/files/<file_id>/download')
def download_file(file_id):
    if not is_authenticated():
        return jsonify({'error': 'Unauthorized'}), 401
    return jsonify({'message': 'File download would start here'})

@app.route('/api/files/<file_id>/archive', methods=['POST'])
def archive_file(file_id):
    if 'division' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    division_id = int(session['division'][3:])
    if division_id in files_db:
        for file in files_db[division_id]:
            if file['id'] == file_id:
                file['archived'] = True
                return jsonify({'success': True})
    
    return jsonify({'error': 'File not found'}), 404

@app.route('/api/divisions/<int:division_id>/files/<file_id>', methods=['DELETE'])
def delete_file(division_id, file_id):
    if not is_admin():
        return jsonify({'error': 'Unauthorized'}), 401
    
    if division_id in files_db:
        files_db[division_id] = [f for f in files_db[division_id] if f['id'] != file_id]
        return jsonify({'success': True})
    return jsonify({'error': 'Division not found'}), 404

@app.route('/templates/<template_type>')
def download_template_file(template_type):
    if template_type not in template_files or not template_files[template_type]:
        return jsonify({'error': 'Template not found'}), 404
    return send_from_directory(app.config['TEMPLATE_FOLDER'], template_files[template_type])

@app.route('/upload_template', methods=['POST'])
def upload_template():
    if not is_admin():
        return jsonify({'error': 'Unauthorized'}), 401
    
    if 'template_file' not in request.files:
        return jsonify({'error': 'No file part'}), 400
    
    file = request.files['template_file']
    file_type = request.form.get('file_type')
    
    if not file or file.filename == '':
        return jsonify({'error': 'No selected file'}), 400
    
    if not allowed_file(file.filename):
        return jsonify({'error': 'Invalid file type'}), 400
    
    filename = secure_filename(file.filename)
    save_path = os.path.join(app.config['TEMPLATE_FOLDER'], f"template_{file_type}_{filename}")
    
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    file.save(save_path)
    
    template_files[file_type] = filename
    return jsonify({'success': True, 'message': 'Template uploaded successfully'})

@app.route('/api/templates/<template_type>', methods=['DELETE'])
def delete_template(template_type):
    if not is_admin():
        return jsonify({'error': 'Unauthorized'}), 401
    
    if template_type in template_files:
        template_files[template_type] = None
        return jsonify({'success': True})
    return jsonify({'error': 'Template not found'}), 404

if __name__ == '__main__':
    app.run(debug=True)
